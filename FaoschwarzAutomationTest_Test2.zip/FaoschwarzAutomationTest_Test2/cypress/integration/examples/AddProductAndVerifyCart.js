/// <reference types="Cypress" />
import HomePage from "../pageObjects/HomePage";
import ProductDetailPage from "../pageObjects/ProductDetailPage";

const homePage = new HomePage();
const productDetailsPage = new ProductDetailPage();

describe('Verify the functionality of add product to the cart flow', function () {
  before(function () {
    cy.fixture('example').then(function (data) {
      this.data = data;
    });

    Cypress.on('uncaught:exception', (err) => {
      const ignoredErrors = [
        'window.WISER_INIT is not a function',
        'usoAjaxCartBootstrap is not defined',
        'ResizeObserver loop completed with undelivered notifications',
        'window.reload is not a function'
      ];
      if (ignoredErrors.some(ignoredError => err.message.includes(ignoredError))) {
        return false;
      }
      return true;
    });
  });

  it('Verify that the functionality of add product to the cart and view the cart', function () {
    let totalPrice = 0;
    let itemQty = 3;
    cy.navigateToFaoschwarzWebsite();
    cy.searchForCars(this.data.searchKey);

    cy.intercept('GET', '**/search?klevu_term=cars**').as('searchResults');
    cy.wait('@searchResults').then((interception) => {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(interception.response.body, 'text/xml');
      const responseValue = xmlDoc.getElementsByTagName('response')[0].childNodes[0].nodeValue;
      expect(responseValue).to.equal('SUCCESS');
      homePage.selectProduct().should('be.visible').click();
    });

    productDetailsPage.getPageTitle().should('be.visible');
    productDetailsPage.getDetailPageProductTitle().then((element) => {
      cy.wrap(element.text().trim()).as('actualText');
    });
    cy.get('@actualText').then((actualText) => {
      cy.log('Product detailed page has been opened and product title is visible as ' + actualText);
    });

    productDetailsPage.getProductPrice().then((element) => {
      const amount = element.text().replace('$', '').trim();
      totalPrice = Number(amount) * itemQty;
      cy.wrap(totalPrice).as('totalPrice');
    });

    productDetailsPage.getQuantityField().clear().type(itemQty);
    productDetailsPage.getAddToCartButton().click();
    productDetailsPage.getCartSlider().should('be.visible');

    cy.get('@totalPrice').then((totalPrice) => {
      productDetailsPage.getCartSubTotal().should('be.visible').and('contain.text', totalPrice);
    });

    productDetailsPage.getCartQuantity().should('be.visible').and('have.value', itemQty);
    productDetailsPage.getChatIcon().should('be.visible');
  });
});