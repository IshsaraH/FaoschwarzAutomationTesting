class HomePage{
    getHomePageLogo(){
        return cy.get("a.site-header__logo-link.logo--has-inverted");
    }

    getAcceptCookies(){
        return cy.get('#onetrust-accept-btn-handler');
    }
    getSearchIcon(){
        return cy.get('.js-search-header')
    }

    getSearchField(){
        return cy.get('.site-header__search-input');
        
    }
    getSubmitSearchIcon(){
        return cy.get('.site-header__search-btn--submit');
    }
    getSortField(){
        return cy.get('.kuDropdown.kuDropSortBy');
    }
    getDropdownField(){
        return cy.get('.kuDropdown.kuDropSortBy .kuDropdownOptions');
    }
    getSortOptionLowToHigh(){
        return cy.get('.kuDropdown.kuDropSortBy .kuDropOption[data-value="PRICE_ASC"]',  { timeout: 10000 });
    }
    selectProduct(){
        return cy.get('div.kuResults > ul > li:nth-of-type(2)', { timeout: 20000 })
               
    }


}

export default HomePage;