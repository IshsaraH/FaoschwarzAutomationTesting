class ProductDetailPage{
   getPageTitle(){
    return cy.get('.product-block.product-block--header', { timeout: 10000 });
   }
   getDetailPageProductTitle(){
    return cy.get('h1.h2.product-single__title');
   }
   getProductPrice(){
    return cy.get('span.product__price');
   }
   getQuantityField(){
    return cy.get('#Quantity-template--15822213775447__main6579774554199');
   }
   getAddToCartButton(){
    return cy.get('#AddToCart-');
   }
   getCartSlider(){
    return cy.get('.drawer.drawer--right.drawer--is-open');
   }
   getCartSubTotal(){
    return cy.get('div[data-subtotal]', { timeout: 10000 });
   }
   getViewCartButton(){
      return cy.get('#a.addToCart-btn');
   }
   getCartQuantity(){
    return cy.get('input.js-qty__num');
   }
   getChatIcon(){
    return cy.get('#chat-button')
   }
}

export default ProductDetailPage;