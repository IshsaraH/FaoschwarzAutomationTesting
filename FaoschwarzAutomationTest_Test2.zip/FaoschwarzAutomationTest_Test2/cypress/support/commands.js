import HomePage from "../integration/pageObjects/HomePage";

const homePage=new HomePage();

Cypress.Commands.add('navigateToFaoschwarzWebsite', () => { 
cy.visit(Cypress.env('url'));
    homePage.getHomePageLogo().should('be.visible');
    homePage.getAcceptCookies().click()
    })

Cypress.Commands.add('searchForCars',(searchKey)=>{
    
    homePage.getSearchIcon().should('be.visible').click();
    homePage.getSearchField().type(searchKey);
    homePage.getSubmitSearchIcon().click();
    homePage.getSortField().trigger('mouseover');
    homePage.getDropdownField().invoke('show');
    homePage.getSortOptionLowToHigh().should('be.visible').click();
})