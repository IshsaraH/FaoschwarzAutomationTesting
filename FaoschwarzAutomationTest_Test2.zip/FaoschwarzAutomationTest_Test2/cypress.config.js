const cypress = require("Cypress");
const { defineConfig } = require("Cypress");

module.exports = defineConfig({
  reporter: 'cypress-mochawesome-reporter',
    env: {
        url: "https://faoschwarz.com",
      },
  reporterOptions: {
    reportDir: 'cypress/reports',
    overwrite: false,
    html: true,
    json: true,
    charts: true,
  },
  e2e: {
    setupNodeEvents(on, config) {
      require('cypress-mochawesome-reporter/plugin')(on);
      return config;
    },
    specPattern : 'cypress/integration/examples/*.js'
  },
});





// const { defineConfig } = require("cypress");
// const preprocessor = require("@badeball/cypress-cucumber-preprocessor");
// const browserify = require("@badeball/cypress-cucumber-preprocessor/browserify");

// async function setupNodeEvents(on, config) {
//   // This is required for the preprocessor to be able to generate JSON reports after each run, and more,
//   await preprocessor.addCucumberPreprocessorPlugin(on, config);

//   on("file:preprocessor", browserify.default(config));

//   // Make sure to return the config object as it might have been modified by the plugin.
//   return config;
// }
// module.exports = defineConfig({

//   defaultCommandTimeout: 6000,
//   env: {
//     url: "https://faoschwarz.com/search?q=cars.com",
//   },
//   retries: {
//     runMode: 1,

//   },

//   e2e: {
//     setupNodeEvents,
//     specPattern: 'cypress/integration/examples/BDD/*.feature'

//   },
// });

// //messages -> json file ->html